NEXUS RP — Prototype 001

This is an early mobile browser prototype, not a finished native iOS app and not an IPA.

How to run:
1. Upload index.html to a static web host that serves HTTPS, or open it through a local web server.
2. Open the hosted page in Safari on iPhone.
3. Tap SPIEL STARTEN.
4. Use the left joystick to move, SPRINT to run, and FAHRZEUG near the car to enter/exit.

Controls:
- Touch joystick: walk / steer
- SPRINT: run faster
- FAHRZEUG: enter or exit the car
- While driving: joystick up/down accelerates/brakes; left/right steers
- Desktop fallback: WASD and Shift

Technical note:
- Uses Three.js from jsDelivr CDN, so an internet connection is required.
- This is a small prototype scene with placeholder geometry and no multiplayer, account system, weapons, or persistent save data yet.
- To create a signed .ipa, this project must be wrapped in a native iOS app and built/signed by a cloud build service or Mac/Xcode with valid Apple signing credentials. eSign only installs/signs compatible existing packages; it does not compile this game.
